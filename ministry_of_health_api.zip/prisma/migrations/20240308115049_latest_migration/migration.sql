-- AlterTable
ALTER TABLE "facility" ADD COLUMN     "cac_image" TEXT,
ADD COLUMN     "owner_nin_image" TEXT;
