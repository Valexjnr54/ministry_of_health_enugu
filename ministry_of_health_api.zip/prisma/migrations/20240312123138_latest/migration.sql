-- AlterTable
ALTER TABLE "users" ADD COLUMN     "passport" TEXT;
