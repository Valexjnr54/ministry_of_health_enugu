-- AlterTable
ALTER TABLE "facility" ADD COLUMN     "password" TEXT;

-- AlterTable
ALTER TABLE "users" ADD COLUMN     "password" TEXT;
