-- AlterTable
ALTER TABLE "inspection_review" ALTER COLUMN "compliance_certificate" DROP NOT NULL;
