-- AlterTable
ALTER TABLE "facility_price_list" ALTER COLUMN "number_of_beds" SET DATA TYPE TEXT;
