-- AlterTable
ALTER TABLE "facility" ADD COLUMN     "assigned_inspector" TEXT,
ADD COLUMN     "inspection_date" TIMESTAMP(3);
