-- AlterTable
ALTER TABLE "facility" ADD COLUMN     "landmark" TEXT;
