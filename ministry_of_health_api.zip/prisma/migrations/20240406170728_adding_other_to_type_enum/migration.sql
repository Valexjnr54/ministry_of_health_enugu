-- AlterEnum
ALTER TYPE "Type" ADD VALUE 'Other';
