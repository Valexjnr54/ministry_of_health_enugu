-- AlterTable
ALTER TABLE "facility" ADD COLUMN     "is_inspected" BOOLEAN NOT NULL DEFAULT false;
