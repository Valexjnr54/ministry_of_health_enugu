-- AlterTable
ALTER TABLE "inspector" ADD COLUMN     "lga" INTEGER;
