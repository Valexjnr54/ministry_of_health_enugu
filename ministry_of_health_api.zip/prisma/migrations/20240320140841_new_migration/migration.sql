-- AlterTable
ALTER TABLE "users" ADD COLUMN     "state" TEXT;
