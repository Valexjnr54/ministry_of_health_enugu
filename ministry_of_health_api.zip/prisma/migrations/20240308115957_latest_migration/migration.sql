-- AlterTable
ALTER TABLE "users" ADD COLUMN     "nin_image" TEXT,
ADD COLUMN     "practice_certificate" TEXT;
