-- AlterTable
ALTER TABLE "personnel_price_list" ADD COLUMN     "certificate_charge" INTEGER;
