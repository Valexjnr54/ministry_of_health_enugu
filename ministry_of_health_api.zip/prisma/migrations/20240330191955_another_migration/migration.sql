-- AlterTable
ALTER TABLE "inspector" ALTER COLUMN "lga" SET DATA TYPE TEXT;
