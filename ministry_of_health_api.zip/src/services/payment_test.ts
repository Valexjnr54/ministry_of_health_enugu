import { initializePayment } from "../utils/credo";

initializePayment("Valex","+2347015363296",10000,"jimvalex54@gmail.com","Doctor","Registration","https://google.com")